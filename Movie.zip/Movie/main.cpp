#include <iostream>
#include "movie.h"
using namespace std;


int main()
{

    movie Film1("Mad Max ", "G");
    Film1.print(); // First object (first film)

    movie Film2("",""); // Second object (second film)
    Film2.print();

    return 0;

}
