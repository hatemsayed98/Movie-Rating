#ifndef MOVIE_H
#define MOVIE_H
#include<string>
using namespace std;

class movie
{
    public:
        movie();
        movie (string n , string mp );

        string getName();
        string getMPAA();
        void setName(string nam);
        void setMPAA(string mpaa);
        int addRating(int rate);
        float averageRating();
        void Calculate();
        void print();

        virtual ~movie();
    private:
        string name ;
        string MPAA;

};

#endif // MOVIE_H
