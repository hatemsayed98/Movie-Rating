#include "movie.h"
#include<string>
#include <iostream>
using namespace std;
// The following variables are global variables indicate the number of every rate
     float Rate1 = 0;
     float Rate2 = 0;
     float Rate3 = 0;
     float Rate4 = 0;
     float Rate5 = 0;
    float Number_of_Rates; // The total number of rates

movie::movie()
{
      Number_of_Rates = 0; // Default constructor that sets number of rates to 0 every time an object is constructed
}

movie :: movie (string n , string mp )
{
    name = n ;
     MPAA = mp;
}

string movie :: getName(){return name;} //getter to name of movie
string movie :: getMPAA(){return MPAA;} // getter to MPAA of movie

void movie:: setName(string nam) // setter to name of movie
{
    name = nam;
}
void movie:: setMPAA(string mpaa) // setter to MPAA of movie
{
    MPAA = mpaa;
}
int set_Rate() //Input the rate
{
    int Rating;
    cout<< "Enter your rate : \n";
    cin >>Rating;
    return Rating;
}
int movie :: addRating(int rate)// Gives the rates counting
{

    switch (rate){
        case (1):
            Number_of_Rates++; // If rate is 1 Rate1 increases by 1 vote
            Rate1++;
            break;
        case (2):
            Number_of_Rates++; //If rate is 2 Rate1 increases by 1 vote
            Rate2++;
            break;
        case (3) :
            Number_of_Rates++; //If rate is 3 Rate1 increases by 1 vote
            Rate3++;
            break;
        case (4) :
            Number_of_Rates++; //If rate is 4 Rate1 increases by 1 vote
            Rate4++;
            break;
        case (5) :
            Number_of_Rates++; //If rate is 5 Rate1 increases by 1 vote
            Rate5++;
            break;
        }
        return 0 ;
}
movie::~movie()
{
    // Destructor
}

float movie :: averageRating()
{

return (float) ((Rate1 + Rate2*2 + Rate3*3 + Rate4*4 + Rate5*5) / Number_of_Rates );
 // every counter for variable rate * with it's value all divided by total numbers of rates given
}
void movie :: Calculate() // function that takes 6 votes on a film and cout its average
{
    int inp = 0;
    inp = set_Rate();
    addRating(inp);
    inp = set_Rate();
    addRating(inp);
    inp = set_Rate();
    addRating(inp);
    inp = set_Rate();
    addRating(inp);
    inp = set_Rate();
    addRating(inp);
    inp = set_Rate();
    addRating(inp);
    cout<<"\nAverage Rates is : \n"<<averageRating() << "\n\n";
}
void movie :: print() // All the program is integrated in this function
// User Enters name of film, MPAA and 6 rates and the program outputs name , MPAA and average of rates
{
    string name_user , MPAA_user; // User enters name and MPAA
    cout<<"Enter name of film : \n";
     cin>>name_user;
     cout << "Enter MPAA of film (G, PG, PG-13, R): \n";
     cin>>MPAA_user;
     setName(name_user);
     setMPAA(MPAA_user);
     cout<<"\n\nThe Name of Film : \n"<<getName(); // Program prints name and MPAA
     cout<<"\nThe MPAA of the Film : \n"<<getMPAA()<<endl<<endl;
     Calculate();
}


